package com.tathanhloc.faceattendance.Repository;

import com.tathanhloc.faceattendance.Model.KhoaHoc;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KhoaHocRepository extends JpaRepository<KhoaHoc, String> {}
