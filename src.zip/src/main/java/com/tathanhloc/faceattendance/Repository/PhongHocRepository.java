package com.tathanhloc.faceattendance.Repository;

import com.tathanhloc.faceattendance.Model.PhongHoc;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PhongHocRepository extends JpaRepository<PhongHoc, String> {}
