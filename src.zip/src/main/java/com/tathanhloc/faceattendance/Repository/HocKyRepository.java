package com.tathanhloc.faceattendance.Repository;

import com.tathanhloc.faceattendance.Model.HocKy;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HocKyRepository extends JpaRepository<HocKy, String> {}
