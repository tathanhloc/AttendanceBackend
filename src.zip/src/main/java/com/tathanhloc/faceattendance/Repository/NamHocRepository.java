package com.tathanhloc.faceattendance.Repository;

import com.tathanhloc.faceattendance.Model.NamHoc;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NamHocRepository extends JpaRepository<NamHoc, String> {}

