package com.tathanhloc.faceattendance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FaceAttendanceApplication {

    public static void main(String[] args) {
        SpringApplication.run(FaceAttendanceApplication.class, args);
    }

}
