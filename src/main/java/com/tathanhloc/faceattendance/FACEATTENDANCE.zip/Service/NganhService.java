package com.tathanhloc.faceattendance.Service;

import com.tathanhloc.faceattendance.DTO.NganhDTO;
import com.tathanhloc.faceattendance.Model.Nganh;
import com.tathanhloc.faceattendance.Repository.KhoaRepository;
import com.tathanhloc.faceattendance.Repository.NganhRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class NganhService {
    private final NganhRepository repo;
    private final KhoaRepository khoaRepo;

    public List<Nganh> getAll() { return repo.findAll(); }
    public Optional<Nganh> getById(String id) { return repo.findById(id); }
    public Nganh create(NganhDTO dto) {
        Nganh ng = Nganh.builder()
                .maNganh(dto.getMaNganh())
                .tenNganh(dto.getTenNganh())
                .khoa(khoaRepo.findById(dto.getMaKhoa()).orElse(null))
                .build();
        return repo.save(ng);
    }
    public void delete(String id) { repo.deleteById(id); }
}