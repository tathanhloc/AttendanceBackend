package com.tathanhloc.faceattendance.Service;

import com.tathanhloc.faceattendance.Model.Khoa;
import com.tathanhloc.faceattendance.Repository.KhoaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class KhoaService {
    private final KhoaRepository repo;

    public List<Khoa> getAll() { return repo.findAll(); }
    public Optional<Khoa> getById(String id) { return repo.findById(id); }
    public Khoa create(Khoa dto) { return repo.save(dto); }
    public void delete(String id) { repo.deleteById(id); }
}
