package com.tathanhloc.faceattendance.Service;

import com.tathanhloc.faceattendance.Model.DiemDanh;
import com.tathanhloc.faceattendance.Repository.DiemDanhRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class DiemDanhService {
    private final DiemDanhRepository repo;

    public List<DiemDanh> getAll() { return repo.findAll(); }
    public Optional<DiemDanh> getById(Long id) { return repo.findById(id); }
    public DiemDanh create(DiemDanh dd) { return repo.save(dd); }
    public void delete(Long id) { repo.deleteById(id); }
}
