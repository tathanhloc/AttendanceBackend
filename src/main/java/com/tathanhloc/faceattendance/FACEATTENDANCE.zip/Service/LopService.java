package com.tathanhloc.faceattendance.Service;


import com.tathanhloc.faceattendance.DTO.*;
import com.tathanhloc.faceattendance.Model.*;
import com.tathanhloc.faceattendance.Repository.*;
import com.tathanhloc.faceattendance.Util.AutoLogUtil;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class LopService {
    private final LopRepository repo;
    private final KhoaHocRepository khoaHocRepo;
    private final NganhRepository nganhRepo;

    public List<Lop> getAll() { return repo.findAll(); }
    public Optional<Lop> getById(String id) { return repo.findById(id); }
    public Lop create(LopDTO dto) {
        Lop lop = Lop.builder()
                .maLop(dto.getMaLop())
                .tenLop(dto.getTenLop())
                .khoaHoc(khoaHocRepo.findById(dto.getMaKhoahoc()).orElse(null))
                .nganh(nganhRepo.findById(dto.getMaNganh()).orElse(null))
                .build();
        return repo.save(lop);
    }

    public Lop update(String id, LopDTO dto) {
        return repo.findById(id).map(old -> {
            Lop lop = Lop.builder()
                    .maLop(dto.getMaLop())
                    .tenLop(dto.getTenLop())
                    .khoaHoc(khoaHocRepo.findById(dto.getMaKhoahoc()).orElse(null))
                    .nganh(nganhRepo.findById(dto.getMaNganh()).orElse(null))
                    .build();
            return repo.save(lop);
        }).orElse(null);
    }
    public void delete(String id) { repo.deleteById(id); }
}
