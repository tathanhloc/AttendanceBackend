package com.tathanhloc.faceattendance.Service;

import com.tathanhloc.faceattendance.Model.KhoaHoc;
import com.tathanhloc.faceattendance.Repository.KhoaHocRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class KhoaHocService {
    private final KhoaHocRepository repo;

    public List<KhoaHoc> getAll() { return repo.findAll(); }
    public Optional<KhoaHoc> getById(String id) { return repo.findById(id); }
    public KhoaHoc create(KhoaHoc dto) { return repo.save(dto); }
    public void delete(String id) { repo.deleteById(id); }
}