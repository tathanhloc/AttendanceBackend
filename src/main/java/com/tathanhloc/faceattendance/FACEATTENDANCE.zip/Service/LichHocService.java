package com.tathanhloc.faceattendance.Service;

import com.tathanhloc.faceattendance.DTO.LichHocDTO;
import com.tathanhloc.faceattendance.Model.LichHoc;
import com.tathanhloc.faceattendance.Repository.LichHocRepository;
import com.tathanhloc.faceattendance.Repository.LopHocPhanRepository;
import com.tathanhloc.faceattendance.Repository.PhongHocRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class LichHocService {
    private final LichHocRepository repo;
    private final PhongHocRepository phongRepo;
    private final LopHocPhanRepository lhpRepo;

    public List<LichHoc> getAll() { return repo.findAll(); }
    public Optional<LichHoc> getById(String id) { return repo.findById(id); }
    public LichHoc create(LichHocDTO dto) {
        LichHoc lh = LichHoc.builder()
                .maLich(dto.getMaLich())
                .thu(dto.getThu())
                .tietBatDau(dto.getTietBatDau())
                .soTiet(dto.getSoTiet())
                .lopHocPhan(lhpRepo.findById(dto.getMaLhp()).orElse(null))
                .phongHoc(phongRepo.findById(dto.getMaPhong()).orElse(null))
                .build();
        return repo.save(lh);
    }
    public void delete(String id) { repo.deleteById(id); }
}

