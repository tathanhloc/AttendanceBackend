package com.tathanhloc.faceattendance.Service;

import com.tathanhloc.faceattendance.DTO.SystemLogDTO;
import com.tathanhloc.faceattendance.Model.SystemLog;
import com.tathanhloc.faceattendance.Repository.SystemLogRepository;
import com.tathanhloc.faceattendance.Repository.TaiKhoanRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class SystemLogService {
    private final SystemLogRepository repo;

    public List<SystemLog> getAll() { return repo.findAll(); }
    public Optional<SystemLog> getById(Long id) { return repo.findById(id); }
    public SystemLog create(SystemLog log) { return repo.save(log); }
    public void delete(Long id) { repo.deleteById(id); }
}