package com.tathanhloc.faceattendance.Service;


import com.tathanhloc.faceattendance.DTO.*;
import com.tathanhloc.faceattendance.Model.*;
import com.tathanhloc.faceattendance.Repository.*;
import com.tathanhloc.faceattendance.Util.AutoLogUtil;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class PhongHocService {
    private final PhongHocRepository repo;

    public List<PhongHoc> getAll() { return repo.findAll(); }
    public Optional<PhongHoc> getById(String id) { return repo.findById(id); }
    public PhongHoc create(PhongHoc ph) { return repo.save(ph); }
    public void delete(String id) { repo.deleteById(id); }
}