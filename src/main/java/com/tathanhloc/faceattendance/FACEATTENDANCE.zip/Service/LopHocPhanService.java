package com.tathanhloc.faceattendance.Service;

import com.tathanhloc.faceattendance.Model.LopHocPhan;
import com.tathanhloc.faceattendance.Repository.GiangVienRepository;
import com.tathanhloc.faceattendance.Repository.LopHocPhanRepository;
import com.tathanhloc.faceattendance.Repository.MonHocRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class LopHocPhanService {
    private final LopHocPhanRepository repo;
    private final MonHocRepository monHocRepo;
    private final GiangVienRepository giangVienRepo;

    public List<LopHocPhan> getAll() { return repo.findAll(); }
    public Optional<LopHocPhan> getById(String id) { return repo.findById(id); }
    public LopHocPhan create(LopHocPhan lhp) { return repo.save(lhp); }
    public void delete(String id) { repo.deleteById(id); }
}