package com.tathanhloc.faceattendance.Service;

import com.tathanhloc.faceattendance.Model.MonHoc;
import com.tathanhloc.faceattendance.Repository.MonHocRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class MonHocService {
    private final MonHocRepository repo;

    public List<MonHoc> getAll() { return repo.findAll(); }
    public Optional<MonHoc> getById(String id) { return repo.findById(id); }
    public MonHoc create(MonHoc monHoc) { return repo.save(monHoc); }
    public void delete(String id) { repo.deleteById(id); }
}