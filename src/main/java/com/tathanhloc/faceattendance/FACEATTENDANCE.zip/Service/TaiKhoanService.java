package com.tathanhloc.faceattendance.Service;

import com.tathanhloc.faceattendance.DTO.TaiKhoanDTO;
import com.tathanhloc.faceattendance.Model.TaiKhoan;
import com.tathanhloc.faceattendance.Repository.TaiKhoanRepository;
import com.tathanhloc.faceattendance.Util.AutoLogUtil;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class TaiKhoanService {

    private final TaiKhoanRepository taiKhoanRepository;
    private final PasswordEncoder passwordEncoder;
    private final AutoLogUtil autoLogUtil;

    public List<TaiKhoanDTO> getAll() {
        return taiKhoanRepository.findAll().stream().map(this::toDTO).toList();
    }

    public TaiKhoanDTO getById(Long id) {
        TaiKhoan tk = taiKhoanRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Tài khoản không tồn tại"));
        return toDTO(tk);
    }

    public TaiKhoanDTO create(TaiKhoanDTO dto, HttpServletRequest request) {
        if (taiKhoanRepository.existsByUsername(dto.getUsername())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Tên đăng nhập đã tồn tại");
        }
        TaiKhoan entity = toEntity(dto);
        entity.setPasswordHash(passwordEncoder.encode(dto.getPasswordHash()));
        TaiKhoan saved = taiKhoanRepository.save(entity);
        autoLogUtil.log(saved, request.getRemoteAddr(), "Thêm tài khoản");
        return toDTO(saved);
    }

    public TaiKhoanDTO update(Long id, TaiKhoanDTO dto, HttpServletRequest request) {
        TaiKhoan tk = taiKhoanRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Tài khoản không tồn tại"));

        tk.setUsername(dto.getUsername());
        tk.setVaiTro(dto.getVaiTro());
        tk.setIsActive(dto.getIsActive());

        if (dto.getPasswordHash() != null && !dto.getPasswordHash().isBlank()) {
            tk.setPasswordHash(passwordEncoder.encode(dto.getPasswordHash()));
        }

        TaiKhoan updated = taiKhoanRepository.save(tk);
        autoLogUtil.log(updated, request.getRemoteAddr(), "Cập nhật tài khoản");
        return toDTO(updated);
    }

    public void delete(Long id) {
        TaiKhoan tk = taiKhoanRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Tài khoản không tồn tại"));
        taiKhoanRepository.delete(tk);
    }

    public Optional<TaiKhoan> findByUsername(String username) {
        return taiKhoanRepository.findByUsername(username);
    }

    private TaiKhoanDTO toDTO(TaiKhoan entity) {
        return TaiKhoanDTO.builder()
                .id(entity.getId())
                .username(entity.getUsername())
                .vaiTro(entity.getVaiTro())
                .isActive(entity.getIsActive())
                .build();
    }

    private TaiKhoan toEntity(TaiKhoanDTO dto) {
        return TaiKhoan.builder()
                .id(dto.getId())
                .username(dto.getUsername())
                .vaiTro(dto.getVaiTro())
                .isActive(dto.getIsActive())
                .build();
    }
}
