package com.tathanhloc.faceattendance.Service;


import com.tathanhloc.faceattendance.DTO.*;
import com.tathanhloc.faceattendance.Model.*;
import com.tathanhloc.faceattendance.Repository.*;
import com.tathanhloc.faceattendance.Util.AutoLogUtil;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class GiangVienService {
    private final GiangVienRepository repo;
    private final KhoaRepository khoaRepo;

    public List<GiangVien> getAll() { return repo.findAll(); }
    public Optional<GiangVien> getById(String id) { return repo.findById(id); }
    public GiangVien create(GiangVienDTO dto) {
        GiangVien gv = GiangVien.builder()
                .maGv(dto.getMaGv())
                .hoTen(dto.getHoTen())
                .email(dto.getEmail())
                .isActive(dto.getIsActive())
                .khoa(khoaRepo.findById(dto.getMaKhoa()).orElse(null))
                .build();
        return repo.save(gv);
    }
    public void delete(String id) { repo.deleteById(id); }
}