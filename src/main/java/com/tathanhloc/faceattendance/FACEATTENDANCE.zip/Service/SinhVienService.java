package com.tathanhloc.faceattendance.Service;


import com.tathanhloc.faceattendance.DTO.*;
import com.tathanhloc.faceattendance.Model.*;
import com.tathanhloc.faceattendance.Repository.*;
import com.tathanhloc.faceattendance.Util.AutoLogUtil;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class SinhVienService {
    private final SinhVienRepository repo;
    private final LopRepository lopRepo;

    public List<SinhVien> getAll() { return repo.findAll(); }
    public Optional<SinhVien> getById(String id) { return repo.findById(id); }
    public SinhVien create(SinhVienDTO dto) {
        SinhVien sv = SinhVien.builder()
                .maSv(dto.getMaSv())
                .hoTen(dto.getHoTen())
                .gioiTinh(dto.getGioiTinh())
                .ngaySinh(dto.getNgaySinh())
                .email(dto.getEmail())
                .hinhAnh(dto.getHinhAnh())
                .embedding(dto.getEmbedding())
                .isActive(dto.getIsActive())
                .lop(lopRepo.findById(dto.getMaLop()).orElse(null))
                .build();
        return repo.save(sv);
    }
    public void delete(String id) { repo.deleteById(id); }
}
