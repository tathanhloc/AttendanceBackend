package com.tathanhloc.faceattendance.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "nganh")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Nganh {
    @Id
    @Column(name = "ma_nganh")
    private String maNganh;

    @Column(name = "ten_nganh")
    private String tenNganh;

    @ManyToOne
    @JoinColumn(name = "ma_khoa")
    private Khoa khoa;
}